import React from 'react';

function index() {
    return (
        <section className="cta__section">
            <div className="container">
                <div className="row">
                    <div className="col-12 col-md-6 col-lg-6">
                        
                    </div>
                    <div className="col-12 col-md-6 col-lg-6"></div>
                </div>
            </div>
        </section>
    );
}

export default index;