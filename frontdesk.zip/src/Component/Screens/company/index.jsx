import React from 'react';
import PropTypes from 'prop-types';

index.propTypes = {
    
};

function index(props) {
    return (
        <div>
            Company
        </div>
    );
}

export default index;