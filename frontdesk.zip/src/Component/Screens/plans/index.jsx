import React from 'react';
import PropTypes from 'prop-types';

index.propTypes = {
    
};

function index(props) {
    return (
        <div>
            Plans
        </div>
    );
}

export default index;