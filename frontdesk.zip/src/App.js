import React from 'react';
import Header from './Component/header';
import Home from "./Component/Screens/home";
import Footer from './Component/footer';
import Product from "./Component/Screens/product";
import Company from "./Component/Screens/company";
import Plans from './Component/Screens/plans';
import Contact from './Component/Screens/contact';
import Careers from './Component/Screens/careers';
import { Route, Switch, BrowserRouter as Router } from 'react-router-dom';
import './sass/main.scss';
function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Switch>
          <Route path="/product">
            <Product />
          </Route>
          <Route path="/company">
            <Company />
          </Route>
          <Route path="/plans">
            <Plans />
          </Route>
          <Route path="/contact">
            <Contact />
          </Route>
          <Route path="/careers">
            <Careers />
          </Route>
          <Route exact path="/">
            <Home />
          </Route>
        </Switch>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
